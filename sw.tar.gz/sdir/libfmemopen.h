#ifndef libfmemopen_windows
#define libfmemopen_windows
FILE *fmemopen(void *buf, size_t len, const char *type);
#endif
